library(testthat)
library(lifelihood)
test_package("lifelihood")
