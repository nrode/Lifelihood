rm(list = ls())

devtools::load_all()
devtools::update_packages()
devtools::install()

